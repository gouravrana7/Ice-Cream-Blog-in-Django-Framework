import email
from msilib.schema import ListView
from pyexpat import model
from django.shortcuts import render,HttpResponse



# Create your views here.
def index(request):
    return render(request,'index.html') 
   # return HttpResponse("This is home page")

def about(request):
     return render(request,'about.html')
   # return HttpResponse("This is about page")      

def contacts(request):
     return render(request,'contacts.html')
    #return HttpResponse("This is contacts page")  
   

   
  


